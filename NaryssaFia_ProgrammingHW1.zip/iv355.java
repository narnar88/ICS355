import java.nio.file.*;
import java.nio.file.Paths;
import java.net.*;
import java.lang.*;
import java.util.*;
import java.io.*;
import java.security.*;
import java.math.*;
import java.io.FileReader;
import java.io.IOException;
import java.text.*;

class Account{
    private int acctno;
    private double balance;
    private String currency;
    
    public Account(int acctno, double balace, String currency){
        this.acctno = acctno;
        this.balance = balance;
        this.currency = currency;
    }
    public int getAcctno(){ return acctno; }
    public double getBalance(){ return balance; }
    public String getCurrency(){ return currency; }
    
    public void setAcctno(int acctno) { this.acctno = acctno; }
    public void setBalance(double balance) { this.balance = balance; }
    public void setCurrency(String currency) { this.currency = currency; }

}//end account class

public class iv355{
    public static void main(String[] args){
           
        try {
           File file = new File("ICS355IV.txt");
           File tempFile = new File("temp.txt");//write data from current run here. will replace ICS355IV.txt with temp file
           FileReader reader = new FileReader(file);
           Path p = Paths.get("/Users/naryssa/Desktop/ICS355/ICS355IV.txt");
           Path p2 = Paths.get("/Users/naryssa/Desktop/ICS355/temp.txt");
           InputStream is = Files.newInputStream(p);
           OutputStream os = Files.newOutputStream(p2);
           BufferedReader in = new BufferedReader(reader);
           Scanner infile = new Scanner(file);
           
           Account[] bank = new Account[10]; 
           bank[0] = new Account(1, 0.00, "USD");//initializer for testing

           List<String> records = new ArrayList<String>();
           String line;
           while ((line = in.readLine()) != null)
           {
               records.add(line);
           }
           in.close();
           //read in ICS355IV.txt file
          
           double usd_jpy_rate, usd_aud_rate, jpy_usd_rate, jpy_aud_rate, aud_usd_rate, aud_jpy_rate;
           usd_jpy_rate = Double.parseDouble(find("usd_jpy_rate:", file));
           usd_aud_rate = Double.parseDouble(find("usd_aud_rate:", file));
           jpy_usd_rate = Double.parseDouble(find("jpy_usd_rate:", file));
           jpy_aud_rate = Double.parseDouble(find("jpy_aud_rate:", file));
           aud_usd_rate = Double.parseDouble(find("aud_usd_rate:", file));
           aud_jpy_rate = Double.parseDouble(find("aud_jpy_rate:", file));

           
           Scanner s = new Scanner(System.in); 
        
           int choice = 0;
        
           do{
               System.out.println("Welcome to your bank.");
               System.out.println("To create a new account, enter 1");
               System.out.println("To make a deposit, enter 2"); 
               System.out.println("To withdraw, enter 3");
               System.out.println("To display currency info, enter 4.");
               System.out.println("To get your current balance, enter 5");
               System.out.println("To quit, enter 6");  
               choice = s.nextInt();
               switch(choice){
                   case 1: createacct(bank);
                       
                       break;
                   case 2: deposit(bank, usd_jpy_rate, usd_aud_rate, aud_jpy_rate, aud_usd_rate, jpy_usd_rate, jpy_aud_rate);
                       
                       break;
                   case 3: withdraw(bank, usd_jpy_rate, usd_aud_rate, aud_jpy_rate, aud_usd_rate, jpy_usd_rate, jpy_aud_rate);
                       
                       break;
                   case 4: currencies(usd_jpy_rate, usd_aud_rate, aud_jpy_rate, aud_usd_rate, jpy_usd_rate, jpy_aud_rate);
                       
                       break;
                   case 5: balance(bank);
                       break;
                   case 6: 
                       FileWriter fileWriter = new FileWriter(tempFile);
                       BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                       String usd_jpy_rate_string = String.format("%.3f", usd_jpy_rate);
                       String usd_aud_rate_string = String.format("%.3f", usd_aud_rate);
                       String aud_jpy_rate_string = String.format("%.3f", aud_jpy_rate);
                       String aud_usd_rate_string = String.format("%.3f", aud_usd_rate);
                       String jpy_usd_rate_string = String.format("%.3f", jpy_usd_rate);
                       String jpy_aud_rate_string = String.format("%.3f", jpy_aud_rate);

                       bufferedWriter.write("usd_jpy_rate: " + usd_jpy_rate_string + "\n");
                       bufferedWriter.write("usd_aud_rate: " + usd_aud_rate_string + "\n");
                       bufferedWriter.write("aud_jpy_rate: " + aud_jpy_rate_string + "\n");
                       bufferedWriter.write("aud_usd_rate: " + aud_usd_rate_string + "\n");
                       bufferedWriter.write("jpy_usd_rate: " + jpy_usd_rate_string + "\n");
                       bufferedWriter.write("jpy_aud_rate: " + jpy_aud_rate_string + "\n");
                       bufferedWriter.flush();
                       int i = 0;
                       while(bank[i] != null){
                           
                           String writeBalance = String.format("%.2f", bank[i].getBalance());
                           bufferedWriter.write("bank[" + Integer.toString(i) +"].acctno: " + Integer.toString((i+1)) + "\n");
                           bufferedWriter.write("bank[" + Integer.toString(i) +"].balance: " + writeBalance + "\n");
                           bufferedWriter.write("bank[" + Integer.toString(i) +"].currency: " + bank[i].getCurrency() + "\n");
                           bufferedWriter.flush();
                           i++;
                       }
                       Files.copy(Paths.get("temp.txt"),Paths.get("ICS355IV.txt"), StandardCopyOption.REPLACE_EXISTING);
                       fileWriter.flush();
                       fileWriter.close();
                       
                       bufferedWriter.close();
                       is.close();
                       os.close();
                       System.out.println("Shoots brah");
                       System.exit(0);
                       break;
                   case 7: 
                          Scanner sMaint = new Scanner(System.in); 
                          String command = sMaint.nextLine();
                          int comp = command.compareTo("maint");                            
                           if(comp == 0){
                               System.out.println("For each currency, enter the new conversion rates.");
                               String from_to = "USD to JPY: ";
                               usd_jpy_rate = maintenance(from_to);
                               from_to = "USD to AUD";
                               usd_aud_rate = maintenance(from_to);
                               from_to = "AUD to JPY";
                               aud_jpy_rate = maintenance(from_to);
                               from_to = "AUD to USD";
                               aud_usd_rate = maintenance(from_to);
                               from_to = "JPY to USD";
                               jpy_usd_rate = maintenance(from_to);
                               from_to = "JPY to AUD";
                               jpy_aud_rate = maintenance(from_to);

                           }//end if
                           else{
                               System.out.println("Error, invalid input. Goodbye..."); System.exit(0);
                               
                           
                           }
                      
                       
                   break;
                   default: System.out.println("Error, invalid input. Try again"); choice = s.nextInt();             
       
               }//end switch
           }while(choice != 6);
       
       }   
        
       catch (FileNotFoundException e) {
           e.printStackTrace();
       } 
       catch (IOException e) {
           e.printStackTrace();
       } 
       catch(InputMismatchException e){
           System.out.println("Invalid input");
               
        }//end catch
        
        
       
    }//end main
    
    public static String find(String findThis, File file){
        String result = "";;
        try{
           //Open file
            Path p = Paths.get("/Users/naryssa/Desktop/ICS355/ICS355IV.txt");
            InputStream fis = Files.newInputStream(p);
            FileReader reader = new FileReader("ICS355IV.txt");
            BufferedReader fin = new BufferedReader(reader);
            result = ""; // Return this if findThis can’t be found
            String line = fin.readLine();
            do {
               
               if (line.startsWith(findThis) == true) {
               return line.substring(findThis.length() +1); 
               } // Get the substring of line starting at the character just after findThis.
               line = fin.readLine();
            }
            while (line != null);
            fin.close();
         } 
         catch(FileNotFoundException e) {
             return result;
         }
          catch (IOException e) {
             e.printStackTrace();
          } 

         return result;

    }//end find function


    public static void createacct(Account[] bank){
        try{
        Scanner s1 = new Scanner(System.in);
        int i;
        int j;
        String c;
        
        for(i = 1; i<10; i++){
            j = i+1;
            
            if(bank[i] == null){
                System.out.println("Please enter the currency code for your account (EX: JPY, USD or AUD)");
                c = s1.nextLine();
                
                bank[i] = new Account(j, 0.00, c);
                System.out.println("Your new account number is " + j + ".");    
                break;
            }
            else{i = i;}
        }//end for
        }//end try
        catch(InputMismatchException e){
            System.out.println("Error, invalid");
            createacct(bank);
        }
    }//end createacct
    
    public static void deposit(Account[] bank, double usd_jpy_rate, double usd_aud_rate, double aud_jpy_rate, double aud_usd_rate, double jpy_usd_rate, double jpy_aud_rate){
      try{
        Scanner s2 = new Scanner(System.in);
        String clear;
        boolean currcompare1;
        boolean currcompare2;
       
            
            System.out.println("Please enter account number: ");
            int x = s2.nextInt();
            x = (x-1);
            double currbal = bank[x].getBalance();
            

            System.out.println("Please enter the amount being deposited: ");
            double dep = s2.nextDouble();
            
            System.out.println("Please enter the currency code (USD, AUD, JPY): ");
            String currcode = s2.nextLine();
            s2.nextLine();
            String temp = bank[x].getCurrency();
            
            boolean compare = currcode.equals(temp);
            if(compare = false){
                System.out.println("The currency code you entered is different from the currency currently in your account. Do you want to convert your deposit to " + temp + "? (Y or N). If N, your current balance will be converted to the currency of your deposit.");
                char yorn = s2.next().charAt(0);
                if(yorn == 'Y'){
                   switch(currcode){
                        case "USD": 
                            if(temp == "JPY"){
                                currbal = (dep * usd_jpy_rate) + currbal;
                            }
                            if(temp == "AUD"){
                                currbal = (dep * usd_aud_rate) + currbal;
                            }
                            break;

                       case "JPY":
                           if(temp == "USD"){
                               currbal = (dep * jpy_usd_rate) + currbal;
                           }
                           if(temp == "AUD"){
                               currbal = (dep * jpy_aud_rate) + currbal;
                           }
                           break;

                       case "AUD":
                           if(temp == "USD"){
                               currbal = (dep * aud_usd_rate) + currbal;
                           }
                           if(temp == "JPY"){
                               currbal = (dep * aud_jpy_rate) + currbal;
                           }
                           break;

                     }//end switch

                    
                    bank[x].setBalance(currbal);
                }//end inner if
                
                else if (yorn == 'N' || yorn == 'n'){
                    System.out.println("Your current account balace will be converted to " + currcode);
                    switch(currcode){
                        case "USD": 
                            if(temp == "JPY"){
                                currbal = (currbal * usd_jpy_rate) + dep;
                            }
                            if(temp == "AUD"){
                                currbal = (currbal * usd_aud_rate) + dep;
                            }
                            break;

                       case "JPY":
                           if(temp == "USD"){
                               currbal = (currbal * jpy_usd_rate) + dep;
                           }
                           if(temp == "AUD"){
                               currbal = (currbal * jpy_aud_rate) + dep;
                           }
                           break;

                       case "AUD":
                           if(temp == "USD"){
                               currbal = (currbal * aud_usd_rate) + dep;
                           }
                           if(temp == "JPY"){
                               currbal = (currbal * aud_jpy_rate) + dep;
                           }
                           break;

                     }//end switch
                     
                     
                     
                }//end inner else
                
            }//end if
            else{
                
                currbal = currbal + dep;
                bank[x].setBalance(currbal);
            
            }//end outer else. for when currcode and temp are same
        
        System.out.println("Your new balance is: " + currbal);
        
      }//end try
      catch(InputMismatchException e){
          System.out.println("Error, invalid input");
          deposit(bank, usd_jpy_rate, usd_aud_rate, aud_jpy_rate, aud_usd_rate, jpy_usd_rate, jpy_aud_rate);     
      
      }       
    }//end depost
    
    public static void withdraw(Account[] bank, double usd_jpy_rate, double usd_aud_rate, double aud_jpy_rate, double aud_usd_rate, double jpy_usd_rate, double jpy_aud_rate){
        try{
            Scanner s3 = new Scanner(System.in);
            double drawnewbal;
        
            System.out.println("Please enter your account number: ");
            int y = s3.nextInt();
            y = (y-1);
            double currbaldraw = bank[y].getBalance();
            
            System.out.println("Your current balance is: " + currbaldraw);
            System.out.println("Withdraw Amount: ");
            double draw = s3.nextDouble();
            
            
            String currentcurr = bank[y].getCurrency();
            System.out.println("Your current currency is " + currentcurr + ". Withdraw in same currency? Y or N");
            char drawyorn = s3.next().charAt(0);
            if((drawyorn == 'Y') ||( drawyorn == 'y')){
                if(currbaldraw < draw){
                    System.out.println("Error. Insufficient funds. Please try again.");
                    withdraw(bank, usd_jpy_rate, usd_aud_rate, aud_jpy_rate, aud_usd_rate, jpy_usd_rate, jpy_aud_rate);
                }//end inner if
                else if ((currbaldraw > draw) || (currbaldraw == draw)){
                    drawnewbal = currbaldraw - draw;
                    bank[y].setBalance(drawnewbal);
                    System.out.println("Your new balance is: " + drawnewbal);
                }//end inner else
            }//end outer if
            
            else if((drawyorn == 'N') || (drawyorn == 'n')){
                drawnewbal = currbaldraw - draw;
                bank[y].setBalance(drawnewbal);
                System.out.print("");
                System.out.println("Please enter the currency to convert your withdrawal to (AUD, USD, or JPY): ");
                String temp = s3.nextLine();
                switch(currentcurr){
                    case "USD": 
                        if(temp.equals("AUD") == true){
                            draw = draw * usd_aud_rate;
                            System.out.println("Your withdrawal is: " + draw + " " + temp);
                        }
                        else if(temp.equals("JPY") == true){
                           draw = draw * usd_jpy_rate;
                           System.out.println("Your withdrawal is: " + draw + " " + temp);
                        }
                        break;
                    case "AUD":
                        if(temp.equals("USD") == true){
                           draw = draw * aud_usd_rate;
                           System.out.println("Your withdrawal is: " + draw + " " + temp);
                        }
                        if(temp.equals("JPY") == true){
                           draw = draw * aud_jpy_rate;
                           System.out.println("Your withdrawal is: " + draw + " " + temp);
                        }
                        break;
                   case "JPY":
                        if(temp.equals("USD") == true){
                           draw = draw * jpy_usd_rate;
                           System.out.println("Your withdrawal is: " + draw + " " + temp);
                        } 
                        if(temp.equals("AUD") == true){
                           draw = draw * jpy_aud_rate;
                           System.out.println("Your withdrawal is: " + draw + " " + temp);
                        }
                        break;
                }//end switch}
                System.out.println("Your new balance is: " + drawnewbal);
                
              }//end outer else
 
            }//end try
            catch(InputMismatchException e){
                System.out.println("Error, invalid");
                withdraw(bank, usd_jpy_rate, usd_aud_rate, aud_jpy_rate, aud_usd_rate, jpy_usd_rate, jpy_aud_rate);
            }

    }//end withdraw
    
    public static void balance(Account[] bank){
    
        try{
            Scanner s4 = new Scanner(System.in);
            int i;
            System.out.println("Please enter account number: ");
            i = s4.nextInt();
            i = (i-1);
            
            System.out.println("Your current balance is: " + bank[i].getBalance());
        }//end try
        catch(InputMismatchException e){
            System.out.println("Invalid input.. try again");
            balance(bank);
        }//end catch
    }//end balance
    
    
    public static void currencies(double usd_jpy_rate, double usd_aud_rate, double aud_jpy_rate, double aud_usd_rate, double jpy_usd_rate, double jpy_aud_rate){
        System.out.println("Accepted currencies: USD, AUD, JPY");
        System.out.println("1 USD = " + usd_aud_rate + " AUD, " + usd_jpy_rate + " JPY");
        System.out.println("1 AUD = " + aud_jpy_rate + " JPY, " + aud_usd_rate + " USD");
        System.out.println("1 JPY = " + jpy_usd_rate + " USD, " + jpy_aud_rate + " AUD");
    
    }//end currencies
    
    public static double maintenance(String from_to){
        Scanner s5 = new Scanner(System.in);
        
        System.out.println(from_to);
        double newConvert = s5.nextDouble();
              
        return newConvert;
                
    }//end maintenance
    
    

}//end class



